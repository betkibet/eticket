package com.dao;

import com.models.Role;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
@Transactional
public class RolesDaoImpl implements RolesDao {

    @PersistenceContext
    private EntityManager em;

    @Override
    public void create(Role r) {

        em.persist(r);

    }

    @Override
    public void update(Role r) {

    }

    @Override
    public void delete(int id) {

    }

    @Override
    public Role readOne(int id) {
        Role role = em.find(Role.class, id);
        return role;
    }

    @Override
    public List<Role> readAll() {
        List<Role> roles = em.createQuery("Select a from Role a", Role.class).getResultList();
        return roles;
    }

    @Override
    public List<Role> readByUserId(int id) {
        List<Role> roles = em.createQuery("Select a from User a where a.role_id = '" + id + "'", Role.class).getResultList();
        return roles;
    }
}
