package com.dao;

import com.models.User;

import java.util.List;

public interface UserDao {

    void create(User u);
    void update(User u);
    void delete(int id);
    User readOne(int id);
    List<User> readAll();
}
