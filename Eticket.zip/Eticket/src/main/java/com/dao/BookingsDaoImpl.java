package com.dao;

import com.models.Booking;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.constraints.AssertTrue;
import java.util.List;

@Repository
@Transactional

public class BookingsDaoImpl implements BookingsDao{

    @PersistenceContext
    private EntityManager e;

    @Override
    public void create(Booking b) {

        e.persist(b);

    }

    @Override
    public void update(Booking b) {

    }

    @Override
    public void delete(int id) {

    }

    @Override
    public Booking readOne(Booking b) {
        Booking booking = e.find(Booking.class, b);
        return booking;
    }

    @Override
    public List<Booking> readAll() {
        List<Booking> bookings = e.createQuery("Select a from Booking a", Booking.class).getResultList();
        return bookings;
    }

    @Override
    public List<Booking> readByUserId(int id) {
        return null;
    }

    @Override
    public List<Booking> readByEventId(int id) {
        return null;
    }
}
