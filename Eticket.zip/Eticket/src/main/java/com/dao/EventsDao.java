package com.dao;

import com.models.Event;

import java.util.List;

public interface EventsDao {

    void create(Event e);
    void update(Event e);
    void delete(int id);
    Event readOne(int id);
    List<Event> readAll();

}
