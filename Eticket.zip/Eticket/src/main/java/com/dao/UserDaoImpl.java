package com.dao;

import com.models.User;
import com.models.Role;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
@Transactional

public class UserDaoImpl implements UserDao {
    @PersistenceContext
    private EntityManager em;

    @Override
    public void create(User u) {

        System.out.println("at the dao");
       /* u.setRole(getRoleById(u.getRole().getId()));

        em.persist(u);*/

    }

    private Role getRoleById(int id) {
        return em.find(Role.class, id);
    }

    @Override
    public void update(User u) {

    }

    @Override
    public void delete(int id) {
        User user = readOne(id);
        em.remove(user);
    }
    @Override
    public User readOne(int id) {

        User user =em.find(User.class, id);
        return user;
    }

    @Override
    public List<User> readAll() {
        List<User> users = em.createQuery("Select a from User a", User.class).getResultList();
        return users;
    }
}
