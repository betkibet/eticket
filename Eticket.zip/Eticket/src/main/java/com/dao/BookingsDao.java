package com.dao;

import com.models.Booking;

import java.util.List;

public interface BookingsDao {

    void create(Booking b);
    void update(Booking b);
    void delete(int id);
    Booking readOne(Booking b);
    List<Booking> readAll();
    List<Booking> readByUserId(int id);
    List<Booking> readByEventId(int id);


}
