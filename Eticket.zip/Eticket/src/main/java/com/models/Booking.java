package com.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Timestamp;

@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue

    private int id;
    private int event_id;
    private int user_id;
    private String date_booked;
    private String status_b;
    private Timestamp created_at;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEvent_id() {
        return event_id;
    }

    public void setEvent_id(int event_id) {
        this.event_id = event_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }
    public String getDate_booked() {
        return date_booked;
    }

    public void setDate_booked(String date_booked) {
        this.date_booked = date_booked;
    }
    public String getStatus_b() {
        return status_b;
    }

    public void setStatus_b(String status_b) {
        this.status_b = status_b;
    }

    public Timestamp getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Timestamp created_at) {
        this.created_at = created_at;
    }

    @Override
    public String toString() {
        return "Booking{" +
                "id=" + id +
                ", event_id=" + event_id +
                ", user_id=" + user_id +
                ", date_booked='" + date_booked + '\'' +
                ", status_b='" + status_b + '\'' +
                ", created_at=" + created_at +
                '}';
    }
}
