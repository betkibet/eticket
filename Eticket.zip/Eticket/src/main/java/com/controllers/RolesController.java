package com.controllers;

import com.dao.RolesDao;
import com.dao.UserDao;
import com.models.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;


@Controller
public class RolesController {

    @Autowired
    private RolesDao r;

    @RequestMapping(value = "/roles", method = RequestMethod.GET)
    public String indexRole(Model model){
        List<Role> roles = r.readAll();
        model.addAttribute("roles", roles);
        return "roles/index";
    }

    @RequestMapping(value = "/roles/new", method = RequestMethod.GET)
    public String createRole(Model model){
        Role rl = new Role();
        model.addAttribute("roles",rl);

        return "roles/new";
    }

    @RequestMapping(value = "/roles/save", method = RequestMethod.POST)
    public String saveRole(Model model, @ModelAttribute("roles") Role role){
        r.create(role);
        return "redirect:/roles";
    }
}
