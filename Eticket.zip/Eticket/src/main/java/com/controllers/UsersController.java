package com.controllers;

import com.dao.EventsDao;
import com.dao.RolesDao;
import com.dao.UserDao;
import com.models.Role;
import com.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.jws.WebParam;
import java.util.List;

@Controller
public class UsersController {

    @Autowired
    private UserDao u;

    @Autowired
    private RolesDao r;

    @Autowired
    private EventsDao e;

    @RequestMapping(value = "/users", method = RequestMethod.GET)
    public String showUsers(Model model){
        List<User> users = u.readAll();
        model.addAttribute("users",users);
        return "users/index";
    }

    @RequestMapping(value = "/users/new", method = RequestMethod.GET)
    public String createUser(Model model){

        System.out.println("at view");
        User us = new User();
        model.addAttribute("usersave",us);

        List<Role> roles = r.readAll();
        model.addAttribute("roles",roles);

        return "users/new";
    }

    @RequestMapping(value = "/users/new", method = RequestMethod.POST)
    public String saveUser(Model model, @ModelAttribute("usersave") User user, @ModelAttribute("role") Role role){
        System.out.println(user.toString());
        /*

        user.setRole(role);
        u.create(user);
        return "redirect:/users";*/

        return "OOps";
    }

    @RequestMapping(value = "/users/delete/{id}", method = RequestMethod.DELETE)
    public String deleteUser(Model model, @PathVariable("id") int id){
        u.delete(id);
        return "redirect:/users";
    }


}
